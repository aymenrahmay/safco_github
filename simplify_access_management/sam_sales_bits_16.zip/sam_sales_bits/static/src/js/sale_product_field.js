/** @odoo-module **/
import { SaleOrderLineProductField } from "@sale/js/sale_product_field";
import { patch } from "@web/core/utils/patch";
import {onWillStart, useState } from "@odoo/owl";

patch(SaleOrderLineProductField.prototype,'SaleOrderLineProductFieldPatch', {
    setup(){
        this._super();  
        this.access = useState({
            hide_prod_ext_link: false,
            hide_create:false,
            hide_createEdit:false,
        });
        onWillStart(async() => {
            let self = this;
            let res = await this.orm.call(
                "access.management",
                "ishide_sale_product_ext_link",
                [[]]
            );  
            if(res){
                debugger
                // FOR CREATE BUTTON
                this.props.canCreate = res.is_create;
                this.props.canQuickCreate = res.is_create; 
                this.access.hide_create = res.is_create;
                this.quickCreate = res.is_create;
                // FOR EDIT BUTTON
                this.props.canCreateEdit = res.is_createEdit;
                this.access.hide_createEdit = res.is_createEdit;
                // FOR EXTERNAL LINK
                this.props.canOpen = res.is_open;
                if(!res.is_open){
                    this.access.hide_prod_ext_link = true;  
                } 
                // MODIFY STATE
                this.state.activeActions.create = res.is_create;
                this.state.activeActions.createEdit = res.is_createEdit;
            }
        });
    },
    get hasExternalButton() {
        const res = this._super();
        if(res && this.props.canOpen && !this.access.hide_prod_ext_link){return true;}
        else if(res && !this.props.canOpen && this.access.hide_prod_ext_link){return false;} 
        else{return res}
    },
    get Many2XAutocompleteProps(){
        const res = this._super();  
        res.activeActions.create = this.access.hide_create;
        res.activeActions.createEdit = this.access.hide_createEdit;
        return res;
    }
});
